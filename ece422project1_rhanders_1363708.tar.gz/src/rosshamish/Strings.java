package rosshamish;

public class Strings {
    public static final String Header = "\nECE 422, Reliable & Secure Systems Design\n" +
            "Project #1: Fault Tolerant Systems\n" +
            "Ross Anderson (rhanders / 1363708)\n";
}
