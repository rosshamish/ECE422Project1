package rosshamish.exceptions;

public class IllegalIntegersFileException extends Throwable {
    public IllegalIntegersFileException(String s) {
        super(s);
    }
}
