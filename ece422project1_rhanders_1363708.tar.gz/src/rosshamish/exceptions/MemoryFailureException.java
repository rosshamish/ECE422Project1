package rosshamish.exceptions;

public class MemoryFailureException extends Exception {
    public MemoryFailureException(String message) {
        super(message);
    }
}
