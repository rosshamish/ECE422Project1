//package test.rosshamish;
//
//import org.junit.Test;
//
//import static org.junit.Assert.fail;
//
//public class DataSorterBackupTest {
//
//    @Test
//    public void testSortData() throws Exception {
//        fail("Test case not yet implemented");
//
////        DataGenerator dg = new DataGenerator();
////        dg.generateData(DataGenerator.testPath, 100);
////
////        DataSorter sorter = new DataSorterBackup();
////        List<Integer> integers = new ArrayList<Integer>() {{
////            add(0);
////            add(1);
////            add(9);
////            add(-1);
////            add(0);
////            add(100);
////            add(-100);
////        }};
//
////        List<Integer> sorted = sorter.sort(integers);
////        Integer latest = sorted.get(0);
////        for (Integer i: sorted) {
////            assertTrue(i >= latest);
////            latest = i;
////        }
//    }
//}